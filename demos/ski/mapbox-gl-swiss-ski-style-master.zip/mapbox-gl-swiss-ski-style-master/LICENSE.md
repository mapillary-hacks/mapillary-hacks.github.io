Copyright Mapbox, Inc. 2016

Mapbox users are free to try out, tweak, experiment, and play with the style in this repo for use with your Mapbox map so long as you otherwise abide by the [Mapbox Terms of Service](https://www.mapbox.com/tos/) for your account.  
Instructions for adding this style to your Mapbox Studio account are [here](https://www.mapbox.com/help/studio-manual-styles/#upload-a-style).

Please do not use this style off a Mapbox map.